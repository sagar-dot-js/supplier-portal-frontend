import Button from "../components/Button";
import DisplayCard from "../components/DisplayCard/DisplayCard";
import InvoiceCard from "../customComponents/InvoiceCard";
import RecentFAQCard from "../customComponents/RecentFAQCard";
import ReportsCard from "../customComponents/ReportsCard";

const Dashboard = () => {
  return (
    <div className=" custom-px w-full flex flex-col gap-10">
      <div className="flex justify-between w-full ">
        <div className=" w-[40%] ">
          <p className="text-[32px] font-[400] text-[#1765DC]"> Dashboard</p>
          <div className="flex  justify-between ">
            <div className="w-[309px]  ">
              <p className="text-[16px] text-[#8CB5F3]">
                Welcome to{" "}
                <span className="text-[#1765DC]"> Mirats Supplier</span>{" "}
                Dashboard, switch to
                <span className="text-[#1765DC]"> Analytics </span> view for
                deeper insights{" "}
              </p>
            </div>
            <Button
              onClick={(e) => console.log("its working", e)}
              variant="outlined"
              customWidth="200px"
            >
              Analytics View
            </Button>
          </div>
        </div>
        <div className=" w-[60%] flex justify-end items-start">
          <div>
            <p className="text-[#151313] text-[24px]">TestSupplier#1 </p>
            <p className="text-[#666666]">supplieremail@gmail.com</p>{" "}
          </div>
        </div>
      </div>
      <div>
        {/*  */}
        <div className="flex flex-col gap-5">
          <div className="flex gap-4 items-center ">
            <p> RFQs</p>
            <p className="underline text-xs">View All</p>
          </div>
          <div className="flex">
            <div className=" w-[40%] grid grid-cols-2 gap-10">
              <div className="w-[234px]">
                <DisplayCard
                  customWidth="200px"
                  cardHeader="Total RFQs"
                  cardBody="344"
                />
              </div>
              <div className="w-[234px]">
                <DisplayCard
                  customWidth="200px"
                  cardHeader="Card Header1"
                  cardBody="Card Body"
                />
              </div>
              <div className="w-[234px]">
                <DisplayCard
                  customWidth="200px"
                  cardHeader="Card Header1"
                  cardBody="Card Body"
                />
              </div>
              <div className="w-[234px]">
                <DisplayCard
                  customWidth="200px"
                  cardHeader="Card Header1"
                  cardBody="Card Body"
                />
              </div>
            </div>
            <div className="w-[60%] ">
              {" "}
              <RecentFAQCard />
            </div>
          </div>
        </div>
      </div>
      {/*  */}
      <div className="flex flex-col gap-5 ">
        <div className="flex gap-4 items-center ">
          <p> Projects</p>
          <p className="underline text-xs">View All</p>
        </div>
        <div className="flex">
          <div className="w-[234px]">
            <DisplayCard
              customWidth="200px"
              cardHeader="Card Header1"
              cardBody="Card Body"
            />
          </div>
          <div className="w-[234px]">
            <DisplayCard
              customWidth="200px"
              cardHeader="Card Header1"
              cardBody="Card Body"
            />
          </div>
          <div className="w-[234px]">
            <DisplayCard
              customWidth="200px"
              cardHeader="Card Header1"
              cardBody="Card Body"
            />
          </div>
          <div className="w-[234px]">
            <DisplayCard
              customWidth="200px"
              cardHeader="Card Header1"
              cardBody="Card Body"
            />
          </div>
        </div>
      </div>
      {/*  */}
      <div className="flex flex-col gap-5 ">
        <div className="flex gap-4 items-center ">
          <p> Invoice</p>
          <p className="underline text-xs">View All</p>
        </div>
        <div className="flex justify-between">
          <InvoiceCard />
          <InvoiceCard />
          <InvoiceCard />
          <InvoiceCard />
          <InvoiceCard />
        </div>
      </div>
      {/*  */}

      <div className="flex flex-col gap-5 ">
        <div className="flex gap-4 items-center ">
          <p> Invoice</p>
          <p className="underline text-xs">View All</p>
        </div>
        <div className="grid grid-cols-3">
          <ReportsCard />
          <ReportsCard />
          <ReportsCard />
          <ReportsCard />
          <ReportsCard />
          <ReportsCard />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
