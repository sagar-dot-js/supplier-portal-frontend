import React from "react";
import Button from "../components/Button";

const ReportsCard = () => {
  return (
    <div className="border w-[610px] h-[69px] flex justify-between items-center p-5 rounded-[8px]">
      <p>Robas RFQ </p>
      <p>1000789</p>
      <p>View Log</p>
      <Button
        onClick={(e) => console.log("its working", e)}
        variant="outlined"
        customWidth="200px"
      >
        Outlined Button
      </Button>
    </div>
  );
};

export default ReportsCard;
