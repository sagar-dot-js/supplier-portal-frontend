import React from 'react'

const AlertContext = () => {
  return (
    <div>AlertContext</div>
  )
}

export default AlertContext