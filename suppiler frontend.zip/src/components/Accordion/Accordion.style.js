import styled from "styled-components";
import { RiArrowDownSLine } from "react-icons/ri";

export const AccordionWrapper = styled.div``;

export const AccordionContainer = styled.div``;



