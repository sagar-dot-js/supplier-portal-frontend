import Test from "./pages/Test";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import GlobalStyle from "./globalStyles";

function App() {
  return (
    <>
      <Router>
        <GlobalStyle />
        <div className="flex items-center justify-center h-[50px] custom-header text-[#ffff]">
          This is Header
        </div>
        <Routes>
          <Route path="/" element={<Test />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
        {/* <Test />
          <Dashboard/> */}
      </Router>
    </>
  );
}

export default App;
